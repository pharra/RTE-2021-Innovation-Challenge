var searchData=
[
  ['bitrate_110',['bitrate',['../classio_1_1agora_1_1rtc2_1_1_simulcast_stream_config.html#a263bbc9aa82e6c8078b749a83debc0c8',1,'io.agora.rtc2.SimulcastStreamConfig.bitrate()'],['../classio_1_1agora_1_1rtc2_1_1video_1_1_video_encoder_configuration.html#af56e8dd931eca762b66d1a08d7982498',1,'io.agora.rtc2.video.VideoEncoderConfiguration.bitrate()'],['../classio_1_1agora_1_1rtc2_1_1_publisher_configuration_1_1_builder.html#a32bc8b09bbca84ee836acd923b997792',1,'io.agora.rtc2.PublisherConfiguration.Builder.bitRate()']]],
  ['buf_111',['buf',['../classio_1_1agora_1_1rtc2_1_1video_1_1_agora_video_frame.html#a9c91c2df165c2e820799106572adf17c',1,'io::agora::rtc2::video::AgoraVideoFrame']]],
  ['buffer_5ftype_5farray_112',['BUFFER_TYPE_ARRAY',['../classio_1_1agora_1_1rtc2_1_1video_1_1_agora_video_frame.html#a2a5a506f783250b1d0094c8fac870772',1,'io::agora::rtc2::video::AgoraVideoFrame']]],
  ['buffer_5ftype_5fbuffer_113',['BUFFER_TYPE_BUFFER',['../classio_1_1agora_1_1rtc2_1_1video_1_1_agora_video_frame.html#abb0db072d3df78a0c7f171e50fd8995c',1,'io::agora::rtc2::video::AgoraVideoFrame']]],
  ['buffer_5ftype_5fnone_114',['BUFFER_TYPE_NONE',['../classio_1_1agora_1_1rtc2_1_1video_1_1_agora_video_frame.html#a6d811756114e1f87c26c032e72045643',1,'io::agora::rtc2::video::AgoraVideoFrame']]],
  ['buffer_5ftype_5ftexture_115',['BUFFER_TYPE_TEXTURE',['../classio_1_1agora_1_1rtc2_1_1video_1_1_agora_video_frame.html#a689d8648a1d207844cf2fd29fdfb85df',1,'io::agora::rtc2::video::AgoraVideoFrame']]],
  ['buildconfig_116',['BuildConfig',['../classio_1_1agora_1_1base_1_1internal_1_1_build_config.html',1,'io::agora::base::internal']]],
  ['builder_117',['Builder',['../classio_1_1agora_1_1rtc2_1_1_publisher_configuration_1_1_builder.html',1,'io.agora.rtc2.PublisherConfiguration.Builder'],['../classio_1_1agora_1_1rtc2_1_1video_1_1_video_compositing_layout_1_1_builder.html',1,'io.agora.rtc2.video.VideoCompositingLayout.Builder']]]
];
