var searchData=
[
  ['network_5ftype_5fdisconnected_503',['NETWORK_TYPE_DISCONNECTED',['../classio_1_1agora_1_1rtc2_1_1_constants.html#a847bf96d2f999e4fea5df2a0d2c5d870',1,'io::agora::rtc2::Constants']]],
  ['network_5ftype_5flan_504',['NETWORK_TYPE_LAN',['../classio_1_1agora_1_1rtc2_1_1_constants.html#a432036e78b77f7f7a9a4397fd0b5f899',1,'io::agora::rtc2::Constants']]],
  ['network_5ftype_5fmobile_5f2g_505',['NETWORK_TYPE_MOBILE_2G',['../classio_1_1agora_1_1rtc2_1_1_constants.html#ac90aa7be515d38e550ba8622d94fbb3b',1,'io::agora::rtc2::Constants']]],
  ['network_5ftype_5fmobile_5f3g_506',['NETWORK_TYPE_MOBILE_3G',['../classio_1_1agora_1_1rtc2_1_1_constants.html#a8d6920611ccbeb812c72b6b36e9d3c77',1,'io::agora::rtc2::Constants']]],
  ['network_5ftype_5fmobile_5f4g_507',['NETWORK_TYPE_MOBILE_4G',['../classio_1_1agora_1_1rtc2_1_1_constants.html#a23b207341f75a8d3dd2b350d52087a58',1,'io::agora::rtc2::Constants']]],
  ['network_5ftype_5funknown_508',['NETWORK_TYPE_UNKNOWN',['../classio_1_1agora_1_1rtc2_1_1_constants.html#a0c80c0069492c22781d764e570d07b5c',1,'io::agora::rtc2::Constants']]],
  ['network_5ftype_5fwifi_509',['NETWORK_TYPE_WIFI',['../classio_1_1agora_1_1rtc2_1_1_constants.html#acb94122ceae3f16b8422b0a84f368e31',1,'io::agora::rtc2::Constants']]],
  ['networkinfo_510',['NetworkInfo',['../classio_1_1agora_1_1rtc2_1_1_i_rtc_engine_event_handler_1_1_network_info.html',1,'io::agora::rtc2::IRtcEngineEventHandler']]],
  ['networktransportdelay_511',['networkTransportDelay',['../classio_1_1agora_1_1rtc2_1_1_i_rtc_engine_event_handler_1_1_remote_audio_stats.html#a914ff52103890b131b585e402c9b2893',1,'io::agora::rtc2::IRtcEngineEventHandler::RemoteAudioStats']]],
  ['none_512',['NONE',['../enumio_1_1agora_1_1rtc2_1_1_constants_1_1_media_type.html#a107e05f2aa289661ecc901f0f06143b6',1,'io::agora::rtc2::Constants::MediaType']]],
  ['numchannels_513',['numChannels',['../classio_1_1agora_1_1rtc2_1_1_i_rtc_engine_event_handler_1_1_local_audio_stats.html#ad12d8f083c3040daa591a9e4a3c10a04',1,'io.agora.rtc2.IRtcEngineEventHandler.LocalAudioStats.numChannels()'],['../classio_1_1agora_1_1rtc2_1_1_i_rtc_engine_event_handler_1_1_remote_audio_stats.html#afab7d9ec77d6f7f66f638f6d8425d8c4',1,'io.agora.rtc2.IRtcEngineEventHandler.RemoteAudioStats.numChannels()']]]
];
